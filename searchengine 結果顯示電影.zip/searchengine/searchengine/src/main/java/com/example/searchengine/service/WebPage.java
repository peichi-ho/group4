package com.example.searchengine.service;

import java.util.List;

public class WebPage {
    private String url;
    private String name;
    private String content; // 儲存頁面內容
    private double score;   // 儲存分數

    public WebPage(String url, String name, String content) {
        this.url = url;
        this.name = name;
        this.score = 0.0; // 初始分數
    }

    public String getUrl() {
        return url;
    }

    public String getName() {
        return name;
    }

    public double getScore() {
        return score;
    }

    public void setScore(List<Keyword> keywords) {
    	 for (Keyword keyword : keywords) {
             int count = countOccurrences(keyword.getName());
             score += count * keyword.getWeight(); // 分數公式
         }
    }

    /**
     * 計算分數：根據關鍵字出現次數和權重
     * @param keywords 傳入關鍵字列表
     */
   

    /**
     * 計算內容中某個關鍵字的出現次數
     * @param keyword 關鍵字
     * @return 出現次數
     */
    private int countOccurrences(String keyword) {
        if (content == null || keyword == null || keyword.isEmpty()) return 0;
        String lowerKeyword = keyword.toLowerCase(); // 關鍵字也轉小寫
        return (content.length() - content.replace(lowerKeyword, "").length()) / lowerKeyword.length();
    }
}
