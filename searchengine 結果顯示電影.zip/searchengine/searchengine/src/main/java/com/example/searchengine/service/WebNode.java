package com.example.searchengine.service;

import java.util.ArrayList;
import java.util.LinkedList;

public class WebNode {
    private WebPage webPage;
    private double score;
    private ArrayList<WebNode> children;

    public WebNode(WebPage webPage) {
        this.webPage = webPage;
        this.children = new ArrayList<>();
    }

    public void addChild(WebNode child) {
        children.add(child);
    }

    public ArrayList<WebNode> getChildren() {
        return children;
    }

    public void setNodeScore(LinkedList<Keyword> keywords) {
        webPage.setScore(keywords);
        for (WebNode child : children) {
            child.setNodeScore(keywords);
        }
    }

    public double getScore() {
        return webPage.getScore();
    }
}
