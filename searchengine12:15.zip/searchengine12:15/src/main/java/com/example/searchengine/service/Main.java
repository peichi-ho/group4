package com.example.searchengine.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("請輸入查詢關鍵字：");
        String keyword = sc.nextLine();

        try {
            // Step 1: 使用 GoogleQuery 取得搜尋結果
            GoogleQuery googleQuery = new GoogleQuery(keyword);
            HashMap<String, String> results = googleQuery.query();

            // Step 2: 建立關鍵字列表，設定影視相關關鍵字和權重
            ArrayList<Keyword> keywords = new ArrayList<>();
            keywords.add(new Keyword("美劇", 4.0));
            keywords.add(new Keyword("日劇", 4.0));
            keywords.add(new Keyword("韓劇", 4.0));
            keywords.add(new Keyword("台劇", 4.0));
            keywords.add(new Keyword("陸劇", 4.0));
            keywords.add(new Keyword("影評", 2.0)); 
            keywords.add(new Keyword("電影", 5.0));
            keywords.add(new Keyword("演員", 3.0));
            keywords.add(new Keyword("集數", 3.0));
            keywords.add(new Keyword("上映日期", 2.0));
            keywords.add(new Keyword("劇情大綱", 2.0));
            keywords.add(new Keyword("影視作品", 5.0));
            keywords.add(new Keyword("IMDb", 5.0));
            keywords.add(new Keyword("豆瓣", 5.0));
            keywords.add(new Keyword("Rotten Tomatoes", 5.0));

            // Step 3: 用搜尋結果建構 WebTree
            List<WebPage> webPages = new ArrayList<>();
            for (Map.Entry<String, String> entry : results.entrySet()) {
                String title = entry.getKey();
                String url = entry.getValue();
                WebPage webPage = new WebPage(url, title);
                webPages.add(webPage);
            }

            // 構建 WebTree 的根節點
            WebTree webTree = new WebTree(webPages.get(0));

            // 若有多個頁面，將其加入樹中作為子節點
            for (int i = 1; i < webPages.size(); i++) {
                webTree.root.addChild(new WebNode(webPages.get(i)));
            }

            // Step 4: 計算分數並排序
            webTree.setPostOrderScore(keywords);

            System.out.println("\n搜尋結果排序如下：");
            webTree.eularPrintTree();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
