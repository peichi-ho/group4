package com.example.searchengine.service;

import java.util.ArrayList;
import java.util.LinkedList;

public class WebTree {
    private WebNode root;

    public WebTree(WebNode root) {
        this.root = root;
    }

    public void setPostOrderScore(WebNode startNode, LinkedList<Keyword> keywords) {
        for (WebNode child : startNode.getChildren()) {
            setPostOrderScore(child, keywords);
        }
        startNode.setNodeScore(keywords);
    }

    public WebNode getRoot() {
        return root;
    }
}
