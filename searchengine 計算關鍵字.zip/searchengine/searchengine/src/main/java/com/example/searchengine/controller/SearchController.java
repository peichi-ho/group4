//處理與搜尋相關的前後端邏輯，將用戶的請求轉換為 HTML 頁面的回應
//提供一個搜尋介面（HTML 頁面）
package com.example.searchengine.controller;
import com.example.searchengine.service.GoogleQuery;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.HashMap;

@Controller
public class SearchController {

    // 處理首頁，顯示搜尋表單
    @GetMapping("/")
    public String index() {
        return "index"; // 回傳 index.html
    }

    // 處理搜尋請求，顯示結果
    @GetMapping("/search")
    public String search(@RequestParam("query") String query, Model model) {
        try {
        	//將關鍵字傳遞給 GoogleQuery
        	String modifiedQuery = query + " 電影"; 
            GoogleQuery googleQuery = new GoogleQuery(modifiedQuery);
            HashMap<String, String> results = googleQuery.query();

            model.addAttribute("query", query);
            model.addAttribute("results", results);

        } catch (IOException e) {
            model.addAttribute("error", "Error fetching search results. Please try again later.");
            e.printStackTrace();
        }

        return "result";
    }

}
