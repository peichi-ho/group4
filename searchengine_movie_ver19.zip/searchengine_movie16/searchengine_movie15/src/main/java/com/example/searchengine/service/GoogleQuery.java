//模擬執行 Google 搜尋並回傳結果。它主要是透過 Jsoup 分析網頁內容，擷取搜尋結果的標題和 URL
//call google
package com.example.searchengine.service;

import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class GoogleQuery {

	public String searchKeyword;
	public String url;
	public String content;

	public GoogleQuery(String searchKeyword) {

		this.searchKeyword = searchKeyword;
		try {

			searchKeyword += "電影";
			String encodeKeyword = java.net.URLEncoder.encode(searchKeyword, "utf-8");
			this.url = "https://www.google.com/search?q=" + encodeKeyword + "&oe=utf8&num=20";

			// this.url =
			// "https://www.google.com/search?q="+searchKeyword+"&oe=utf8&num=20";
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	private String FetchsubContent(String suburl) {

		String retVal = "";
		URL u = null;
		try {
			u = new URL(suburl);
		} catch (MalformedURLException e) {
			return retVal;
		}
		URLConnection conn = null;
		try {
			conn = u.openConnection();
		} catch (IOException e) {
			return retVal;
		}
		// set HTTP header
		conn.setRequestProperty("User-agent", "Chrome/107.0.5304.107");
		InputStream in = null;
		try {
			in = conn.getInputStream();
		} catch (IOException e) {
			return retVal;
		}
		// 使用 InputStreamReader 和 BufferedReader 循環讀取 HTML。
		// 將讀取到的每一行資料累加到 retVal 中
		InputStreamReader inReader = null;
		try {
			inReader = new InputStreamReader(in, "utf-8");
		} catch (UnsupportedEncodingException e) {
			return retVal;
		}
		BufferedReader bufReader = new BufferedReader(inReader);
		String line = null;

		try {
			while ((line = bufReader.readLine()) != null) {
				retVal += line;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return retVal;
	}

	public String getContent() throws IOException {
		if (content == null) {
			content = fetchContent();
		}
		return content;
	}

	public HashMap<String, String> query() throws IOException {
		if (content == null) {
			content = fetchContent();
		}

		HashMap<String, String> retVal = new HashMap<String, String>();
		/*
		 * some Jsoup source
		 * https://jsoup.org/apidocs/org/jsoup/nodes/package-summary.html
		 * https://www.1ju.org/jsoup/jsoup-quick-start
		 */
		// using Jsoup analyze html string
		Document doc = Jsoup.parse(content);

		// select particular element(tag) which you want
		Elements lis = doc.select("div");
		lis = lis.select(".kCrYT");

		for (Element li : lis) {
			try {
				String citeUrl = li.select("a").get(0).attr("href").replace("/url?q=", "");
				String title = li.select("a").get(0).select(".vvjwJb").text();

				if (title.equals("")) {
					continue;
				}

				//System.out.println("Title: " + title + " , url: " + citeUrl);
				retVal.put(title, citeUrl);

			} catch (IndexOutOfBoundsException e) {
//				e.printStackTrace();
			}
		}

		return retVal;
	}

	private String fetchContent() throws IOException {

		String retVal = "";

		URL u = new URL(url);
		URLConnection conn = u.openConnection();
		// set HTTP header
		conn.setRequestProperty("User-agent", "Chrome/107.0.5304.107");
		InputStream in = conn.getInputStream();
		// 使用 InputStreamReader 和 BufferedReader 循環讀取 HTML。
		// 將讀取到的每一行資料累加到 retVal 中
		InputStreamReader inReader = new InputStreamReader(in, "utf-8");
		BufferedReader bufReader = new BufferedReader(inReader);
		String line = null;

		while ((line = bufReader.readLine()) != null) {

			retVal += line;
		}
		return retVal;
	}
	
	private String cleanContent(String rawHtml) {
        Document doc = Jsoup.parse(rawHtml);
        // Remove unnecessary elements such as script, style, and ads
        doc.select("script, style, iframe").remove();
        doc.select("[class*=ad], [id*=ad]").remove(); // Remove ads
        // Extract and return plain text
        return doc.text();
    }

    public String getPlainText(String url) throws IOException {
        String rawHtml = FetchsubContent(url);
        return cleanContent(rawHtml);
    }
    
    public HashMap<String, String> gettree(HashMap<String, String> results, GoogleQuery googleQuery,Keyword key) throws IOException {
		// 獲取關鍵字列表
		ArrayList<Keyword> keywordArraylist = KeywordList.Keywordinit();
		keywordArraylist.add(key);
		List<WebNode> roots = new ArrayList<>();
		List<String> urlList = new ArrayList<>(results.values());
		List<String> nameList = new ArrayList<>(results.keySet());
		
		
		//int maincount = 0;
		for (String url : urlList) {
			int index = urlList.indexOf(url);
			String title = nameList.get(index);
			// count root url score
			double retcore = 0;
			
			String rootcontent = getPlainText(url);
			if (rootcontent.equals("")) {
				rootcontent = title;//如果主網頁沒有內容，就用標題當內容
			}
			for (Keyword k : keywordArraylist) {
				WordCounter wdc = new WordCounter(url,rootcontent);
				retcore += k.getWeight() * wdc.countKeyword(k.getName());
			}
			
			WebPage rootpage = new WebPage(url, title,rootcontent);
			WebNode root = new WebNode(rootpage);
			rootpage.SetScore(retcore);
			roots.add(root);
			//maincount++;
			// System.out.println("{ "+maincount +" SC="+retcore+ " } title=" + title);
			// System.out.println("Add : 主網頁分數= " + retcore + " rooURL: " + url);

			// 下一步要爬子網頁
			WebPageCrawler crawler = new WebPageCrawler(url);
			List<String> subPages = null;
			//double subscore = 0;
			try {
				subPages = crawler.crawl();
				// 檢查子網頁是否有成功抓取
				if (subPages.isEmpty()) {
					// System.out.println("No subpages found for URL: " + url);
				} else {
					// 把子網頁和主網頁建成樹
					int lp;
					if (subPages.size() > 3)
						lp = 3;
					else
						lp = subPages.size();
					//System.out.println("Get SubPages " + subPages.size() + " lp=" + lp);
					
					
					for (int si = 0; si < lp; si++) {
						String childContent = null;
						String childrul = subPages.get(si);
					
						childContent = getPlainText(childrul);
						if ((childContent == null) || (childContent.length() == 0))
							continue;
						
						// System.out.println("childContent length: " + childContent.length());
						// 取得子頁面的內容
						// using Jsoup analyze html string
						Document doc = Jsoup.parse(childContent);
						String originalTitle = doc.title();
						if (childContent.equals("")) {
							continue;//子網頁內容是空的就跳過
						}
						// System.out.println("Title: " + originalTitle );
						double temscore = 0;
						for (Keyword k : keywordArraylist) {
							WordCounter wdc = new WordCounter(childrul);
							temscore = k.getWeight() * wdc.countKeyword(k.getName());
							retcore  += temscore;
						}
						
						if (temscore == 0) {
							continue;
						} else {
							WebPage childpage = new WebPage(childrul, childContent);
							WebNode childnode = new WebNode(childpage);
							
							childpage.SetScore(temscore);
							childpage.SetName(originalTitle);
							root.addChild(childnode);
							System.out.print(si + " )child 子網頁分數：" + temscore + "  ");
							//System.out.println("child Title: " + originalTitle + " , url: " + childrul);
						}
					} 
					System.out.println("Final root score: " + retcore);// for sub page count lp
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			root.setScore(retcore);
			
			WebTree tree = new WebTree(root);
			tree.setPostOrderScore(keywordArraylist);
		} // root loop
		
		
		Collections.sort(roots, new Comparator<WebNode>() {
			@Override
			public int compare(WebNode wn1, WebNode wn2) { // 比較分數，從高到低 return
				return Double.compare(wn2.getScore(), wn1.getScore());
			}
		});
		
		System.out.println("\n\n\n=====================\n roots.size=" + roots.size());
		HashMap<String, String> sortresults = new LinkedHashMap<String, String>();
		
		for (int idx = 1; idx < roots.size(); idx++) {
			WebNode ds = roots.get(idx);
			System.out.println(idx + ") score=" + ds.webPage.getScore() + " " + ds.webPage.getName());
			sortresults.put(ds.webPage.getName(), ds.webPage.getUrl());
			//if (idx > 20)
			//	break;
		}

		
		return sortresults;
	}
	

}