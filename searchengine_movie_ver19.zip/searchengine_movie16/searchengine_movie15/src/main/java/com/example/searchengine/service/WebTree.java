package com.example.searchengine.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;

public class WebTree {
    private WebNode root;
    public double rootscore;
    public WebTree(WebNode root) {
        this.root = root;
        this.rootscore = 0;
    }
    public void setPostOrderScore(ArrayList<Keyword> keywords) throws IOException{
		setPostOrderScore(root, keywords);
		this.rootscore = root.getScore();
	}

	private void setPostOrderScore(WebNode startNode,ArrayList<Keyword> keywords) throws IOException{
		startNode.setNodeScore(keywords);
	}

    public WebNode getRoot() {
        return root;
    }
}
