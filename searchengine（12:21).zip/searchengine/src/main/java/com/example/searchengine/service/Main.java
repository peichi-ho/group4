package com.example.searchengine.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Get user input for the search query
        Scanner sc = new Scanner(System.in);
        System.out.println("\u8acb\u8f38\u5165\u67e5\u8a62\u95dc\u9375\u5b57：");
        String keyword = "影視"+sc.nextLine();
        sc.close();

        // Define a list of keywords and their weights
        ArrayList<Keyword> keywords = new ArrayList<>();
        keywords.add(new Keyword("\u7f8e\u5287", 4));
        keywords.add(new Keyword("\u65e5\u5287", 4));
        keywords.add(new Keyword("\u97d3\u5287", 4));
        keywords.add(new Keyword("\u53f0\u5287", 4));
        keywords.add(new Keyword("\u9678\u5287", 4));
        keywords.add(new Keyword("\u97f3\u6a02\u5287", 4));
        keywords.add(new Keyword("\u5f71\u8a55", 2));
        keywords.add(new Keyword("\u96fb\u5f71", 5));
        keywords.add(new Keyword("\u6f14\u54e1", 3));
        keywords.add(new Keyword("\u96c6\u6578", 3));
        keywords.add(new Keyword("\u4e0a\u6620\u65e5\u671f", 2));
        keywords.add(new Keyword("\u5287\u60c5\u5927\u7db1", 2));
        keywords.add(new Keyword("\u5f71\u8996\u4f5c\u54c1", 5));
        keywords.add(new Keyword("IMDb", 5));
        keywords.add(new Keyword("\u8c46\u74e3", 5));
        keywords.add(new Keyword("Rotten Tomatoes", 5));

        // Perform the search
        GoogleQuery gq = new GoogleQuery(keyword);
        HashMap<String, String> results;
        try {
            results = gq.query();
            if (results.isEmpty()) {
                System.out.println("GoogleQuery.query() \u8fd4\u56de\u7a7a\u7d50\u679c\uff0c\u8acb\u6aa2\u67e5 HTML \u89e3\u6790\u908f\u8f2f\u3002");
            } else {
                System.out.println("\u6210\u529f\u89e3\u6790\u67e5\u8a62\u7d50\u679c\uff1a");
                results.forEach((key, value) -> System.out.println("\u6a19\u984c\uff1a" + key + "\uff0cURL\uff1a" + value));
            }
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        // Create a root web page (query string as the name)
        WebPage rootPage = new WebPage("https://www.google.com/search?q=" + keyword, "\u67e5\u8a62\uff1a" + keyword);
        WebTree tree = new WebTree(rootPage);

        // Add search results as child nodes
        for (Map.Entry<String, String> entry : results.entrySet()) {
            String title = entry.getKey();
            String url = entry.getValue();

            // Filter out unwanted websites (e.g., too many unrelated subpages)
            if (url.contains("worldjournal.com") || url.contains("news")) {
                System.out.println("Filtered Out: " + url);
                continue;
            }

            WebPage page = new WebPage(url, title);
            WebNode node = new WebNode(page);
            tree.root.addChild(node);
            System.out.println("\u5df2\u6dfb\u52a0\u7bc0\u9ede - \u6a19\u984c\uff1a" + title + "\uff0cURL\uff1a" + url);

            // Fetch and add children nodes
            try {
                node.fetchAndAddChildren(keywords); // Corrected method name
            } catch (IOException e) {
                System.out.println("Failed to fetch children for: " + title);
            }
        }

        // Calculate scores (post-order traversal)
        try {
            tree.setPostOrderScore(keywords);
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            // 設定每個節點最多爬取 3 個子網頁
            int maxChildrenPerNode = 3;
            tree.fetchChildNodes(maxChildrenPerNode, keywords);
        
            // 計算分數（後序遍歷）
            tree.setPostOrderScore(keywords);
        } catch (IOException e) {
            e.printStackTrace();
        }
        

        // Sort child nodes by score in descending order
        ArrayList<WebNode> allNodes = new ArrayList<>();
        tree.root.children.forEach(node -> {
            allNodes.add(node);
            allNodes.addAll(node.children); // Include child nodes
        });

        // Sort child nodes by score in descending order
        try {
            // 計算節點分數（後序遍歷）
            tree.setPostOrderScore(keywords);
        
            // 對所有子節點進行排序
            for (WebNode child : tree.root.children) {
                Collections.sort(child.children, (o1, o2) -> Double.compare(o2.nodeScore, o1.nodeScore));
            }
        
            // 對根節點的子節點排序
            Collections.sort(tree.root.children, (o1, o2) -> Double.compare(o2.nodeScore, o1.nodeScore));
        
            // 輸出結果
            System.out.println("搜尋結果（依影視相關度排序）：");
            for (WebNode child : tree.root.children) {
                System.out.println("標題：" + child.webPage.name);
                System.out.println("URL：" + child.webPage.url);
                System.out.println("分數：" + child.nodeScore);
                System.out.println("-----------------------");
        
               
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        
    }
}
