package com.example.searchengine.service;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;

public class WebNode {
    public WebNode parent;
    public ArrayList<WebNode> children;
    public WebPage webPage;
    public double nodeScore;

    public WebNode(WebPage webPage) {
        this.webPage = webPage;
        this.children = new ArrayList<>();
    }

    public void setNodeScore(ArrayList<Keyword> keywords) throws IOException {
        webPage.setScore(keywords);
        nodeScore = webPage.score;
        for (WebNode child : children) {
            nodeScore += child.nodeScore;
        }
    }

    public void addChild(WebNode child) {
        this.children.add(child);
        child.parent = this;
    }

    public void fetchAndAddChildren(ArrayList<Keyword> keywords) throws IOException {
        Document doc = Jsoup.connect(this.webPage.url)
                            .timeout(5000) // 增加超時設定
                            .userAgent("Mozilla/5.0")
                            .get();

        Elements links = doc.select("a[href]"); // 抓取所有超連結
        Elements images = doc.select("img[src]"); // 抓取所有圖片

        // 處理圖片節點
        for (Element img : images) {
            String imgUrl = img.attr("abs:src");
            if (imgUrl.endsWith(".jpg") || imgUrl.endsWith(".png")) { // 過濾圖片格式
                WebPage imgPage = new WebPage(imgUrl, "Image: " + imgUrl);
                WebNode imgNode = new WebNode(imgPage);
                this.addChild(imgNode);
                System.out.println("Added Image Node: " + imgUrl);
            }
        }

        // 處理子網頁節點
        for (Element link : links) {
            String childUrl = link.attr("abs:href");
            String childTitle = link.text();

            // 過濾掉包含特定關鍵字的 URL，例如新聞或廣告
            if (childUrl.contains("news") || childUrl.contains("ad")) {
                System.out.println("Filtered Out: " + childUrl);
                continue;
            }

            if (!childUrl.isEmpty() && !childTitle.isEmpty()) {
                WebPage childPage = new WebPage(childUrl, childTitle);
                WebNode childNode = new WebNode(childPage);
                childPage.setScore(keywords); // 設置關鍵字分數
                this.addChild(childNode);
                System.out.println("Added Node: " + childTitle + " (" + childUrl + ")");
            }
        }
    }
    public void fetchAndSetChildScores(ArrayList<Keyword> keywords, int maxChildren) throws IOException {
        if (webPage == null || maxChildren <= 0) return;
    
        // 使用 JSoup 解析主網頁的子連結
        Document doc = Jsoup.connect(webPage.url)
            .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36")
            .get();
        Elements links = doc.select("a[href]");
        int count = 0;
    
        for (Element link : links) {
            if (count >= maxChildren) break; // 限制子網頁數量
            String childUrl = link.absUrl("href");
            String childTitle = link.text();
    
            if (!childUrl.isEmpty() && !childTitle.isEmpty()) {
                WebPage childPage = new WebPage(childUrl, childTitle);
                WebNode childNode = new WebNode(childPage);
                this.addChild(childNode);
    
                // 設定子網頁的分數
                childNode.setNodeScore(keywords);
                count++;
            }
        }
    }
    

    public boolean isTheLastChild() {
        if (this.parent == null) return true;
        ArrayList<WebNode> siblings = this.parent.children;
        return this.equals(siblings.get(siblings.size() - 1));
    }

    public int getDepth() {
        int depth = 1;
        WebNode current = this;
        while (current.parent != null) {
            depth++;
            current = current.parent;
        }
        return depth;
    }
}
