package com.example.searchengine.service;

import java.io.IOException;
import java.util.ArrayList;

public class WebTree {
    public WebNode root;

    public WebTree(WebPage rootPage) {
        this.root = new WebNode(rootPage);
    }

    public void setPostOrderScore(ArrayList<Keyword> keywords) throws IOException {
        setPostOrderScore(root, keywords);
    }

    private void setPostOrderScore(WebNode node, ArrayList<Keyword> keywords) throws IOException {
        for (WebNode child : node.children) {
            setPostOrderScore(child, keywords);
            child.setNodeScore(keywords);
        }
        node.setNodeScore(keywords);
    }

    public void eulerPrintTree() {
        eulerPrintTree(root);
    }

    private void eulerPrintTree(WebNode node) {
        int depth = node.getDepth();
        if (depth > 1) System.out.print("\n" + repeat("\t", depth - 1));
        System.out.print("(" + node.webPage.name + "," + node.nodeScore);
        for (WebNode child : node.children) {
            eulerPrintTree(child);
        }
        System.out.print(")");
        if (node.isTheLastChild()) System.out.print("\n" + repeat("\t", depth - 2));
    }
    public void fetchChildNodes(int maxChildrenPerNode, ArrayList<Keyword> keywords) throws IOException {
        fetchChildNodes(root, maxChildrenPerNode, keywords);
    }
    
    private void fetchChildNodes(WebNode node, int maxChildrenPerNode, ArrayList<Keyword> keywords) throws IOException {
        node.fetchAndSetChildScores(keywords, maxChildrenPerNode);
        for (WebNode child : node.children) {
            fetchChildNodes(child, maxChildrenPerNode, keywords);
        }
    }
    

    private String repeat(String str, int times) {
        return str.repeat(times);
    }
}
