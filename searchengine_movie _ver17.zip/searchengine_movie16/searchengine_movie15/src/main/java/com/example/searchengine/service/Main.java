package com.example.searchengine.service;
import java.util.ArrayList;

import java.io.IOException;

import java.util.Scanner;
import java.util.List;
import java.util.HashMap;
import java.util.LinkedHashMap;

public class Main 
{
    public static void main(String[] args) 
    {
	    Scanner sc = new Scanner(System.in);
	    KeywordList keywordList = new KeywordList();
	    System.out.println("請輸入查詢關鍵字：");
	    String keyword = sc.nextLine();
	    Keyword userKeyword = new Keyword(keyword, 0, 50); 
	    keywordList.add(userKeyword);
        try 
        {
        	 GoogleQuery gq = new GoogleQuery(keyword);
             // 呼叫 query 方法，假設 query 需要傳入 KeywordList 中的 keywords
             //HashMap<String, String> results = gq.query(keywordList.getKeywords());
             HashMap<String, String> results = gq.query();  
             System.out.println("Number of results from GoogleQuery: " + results.size());
             HashMap<String, String> urttray= gq.gettree(results,gq,userKeyword);		
             
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
    }
}
