//處理與搜尋相關的前後端邏輯，將用戶的請求轉換為 HTML頁面的回應
//提供一個搜尋介面（HTML 頁面）
package com.example.searchengine.controller;
import com.example.searchengine.service.GoogleQuery;
import com.example.searchengine.service.Keyword;
import com.example.searchengine.service.KeywordList;
import com.example.searchengine.service.WebNode;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;

@Controller
public class SearchController {
	
	// private final GoogleSearchService googleSearchService;
	// public SearchController(GoogleSearchService googleSearchService) {
	    //    this.googleSearchService = googleSearchService;
//	 }
	 
    // 處理首頁，顯示搜尋表單
    @GetMapping("/")
    public String index() {
        return "index"; // 回傳 index.html
    }

    // 處理搜尋請求，顯示結果
    @GetMapping("/search")
    public String search(@RequestParam("query") String query, Model model) {
        try { 	//將關鍵字傳遞給 GoogleQuery
        	
    	    Keyword userKeyword = new Keyword(query, 0, 50); 
        	String modifiedQuery = query + " 電影"; 
            GoogleQuery googleQuery = new GoogleQuery(modifiedQuery);
            HashMap<String, String> results = googleQuery.query();
            HashMap<String, String> urttray= googleQuery.gettree(results,googleQuery,userKeyword);

            System.out.println("Number of results from GoogleQuery: " + results.size());
            model.addAttribute("query", query);
            model.addAttribute("results", urttray);

        } catch (IOException e) {
            model.addAttribute("error", "Error fetching search results. Please try again later.");
            e.printStackTrace();
        }
        return "result";
    }

}
