package com.example.searchengine.service;
import java.util.ArrayList;

import java.io.IOException;

import java.util.Scanner;
import java.util.List;
import java.util.HashMap;
import java.util.LinkedHashMap;

public class Main 
{
    public static void main(String[] args) 
    {
	    Scanner sc = new Scanner(System.in);
	    KeywordList keywordList = new KeywordList();
	    System.out.println("請輸入查詢關鍵字：");
	    String keyword = sc.nextLine();
	    Keyword userKeyword = new Keyword(keyword, 0, 10); 
	    keywordList.add(userKeyword);
        try 
        {
        	 GoogleQuery gq = new GoogleQuery(keyword);
             // 呼叫 query 方法，假設 query 需要傳入 KeywordList 中的 keywords
             //HashMap<String, String> results = gq.query(keywordList.getKeywords());
             HashMap<String, String> results = gq.query();
             //Collection<String> urls = results.values();
             List<WebNode> roots = new ArrayList<>();
             List<String> urlList = new ArrayList<>(results.values());
             for(String url : urlList) {
            	 WebPage rootpage = new WebPage(url);
                 WebNode root = new WebNode(rootpage);
                 roots.add(root);
                 //下一步要爬子網頁
                 WebPageCrawler crawler = new WebPageCrawler(url);
                 List<String>subPages = crawler.crawl(); 
                 //把子網頁和主網頁建成樹
                 for(String suburl:subPages) {
                	 WebPage subpage = new WebPage(suburl);
                	 WebNode subnode = new WebNode(subpage);
                	 root.addChild(subnode);
                 }
             }
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
    }
}
