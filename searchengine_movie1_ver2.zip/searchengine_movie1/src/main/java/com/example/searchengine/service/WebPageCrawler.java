package com.example.searchengine.service;
import java.io.IOException;             // 處理可能拋出的 IO 異常
import java.util.ArrayList;            // 用於定義和操作 ArrayList
import java.util.List;                 // 定義返回的 List 結構

import org.jsoup.Jsoup;                // 用於從 URL 抓取和解析 HTML
import org.jsoup.nodes.Document;       // 表示 HTML 文檔的 Jsoup 類
import org.jsoup.nodes.Element;        // 表示 HTML 標籤的 Jsoup 類
import org.jsoup.select.Elements;      // 表示多個 Element 的集合


public class WebPageCrawler {
	public String url;//這是主網頁
	public WebPageCrawler(String url) {
        this.url = url;
    }
	public List<String> crawl() throws IOException {
	    List<String> subPageUrls = new ArrayList<>();
	    try {
	        Document doc = Jsoup.connect(url).get();
	        Elements links = doc.select("a[href]");
	        for (Element link : links) {
	            String subPageUrl = link.attr("abs:href");
	            subPageUrls.add(subPageUrl);
	        }
	    } catch (IOException e) {
	        System.err.println("Failed to fetch content from URL: " + url);
	        throw e; // 如果需要，將例外繼續拋出
	    }
	    return subPageUrls;
	}
}
