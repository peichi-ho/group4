package com.example.searchengine.service;

import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("請輸入查詢關鍵字：");
        String keyword = sc.nextLine();
        try {
            /*
             * Using different keyword depends on the last number of your student ID
             * 0,1:Tomato
             * 2,3:Liver
             * 4,5:Pokemon
             * 6,7:Tissue
             * 8,9:Process
             */
            System.out.println(new GoogleQuery(keyword).query());
            // System.out.println(new GoogleQuery("µf­X").query());
        } catch (IOException e) {
            e.printStackTrace();
        }
        sc.close();
    }

}
