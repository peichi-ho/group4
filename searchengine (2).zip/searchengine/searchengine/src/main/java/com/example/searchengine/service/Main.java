package com.example.searchengine.service;

import java.io.IOException;
import java.util.Scanner;

import com.example.searchengine.controller.SearchController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class Main 
{
    public static void main(String[] args) 
    {
    Scanner sc = new Scanner(System.in);
    ArrayList<Keyword> keywordList = new ArrayList();
    System.out.println("Hello");
    System.out.println("請輸入查詢關鍵字：");
    String keyword = sc.nextLine();
    String modifiedKeyword = keyword + " 電影"; 
    Keyword userKeyword = new Keyword(modifiedKeyword, 0, 10);
    keywordList.add(userKeyword);
    //GoogleSearchService googleSearchService=new GoogleSearchService();
   // SearchController searchController=new SearchController(googleSearchService);
    //searchController.search(keyword, null);

        try 
        {
        	System.out.println("敏柔加油");
        	GoogleQuery gq = new GoogleQuery(modifiedKeyword);
            // 呼叫 query 方法，假設 query 需要傳入 KeywordList 中的 keywords
            //HashMap<String, String> results = gq.query(keywordList.getKeywords());
            HashMap<String, String> results = gq.query();  
            
            System.out.println("Number of results from GoogleQuery: " + results.size());
            
            List<WebNode> roots = new ArrayList<>();
            List<String> urlList = new ArrayList<>(results.values());
            List<String> nameList = new ArrayList<>(results.keySet());
            
           
            for(String url : urlList) {
           	 int index =  urlList.indexOf(url);
           	 String title = nameList.get(index);
           	 
           	 WebPage rootpage = new WebPage(url,title);
                WebNode root = new WebNode(rootpage);
                roots.add(root);
                WebTree tree = new WebTree(root);
                //下一步要爬子網頁
                System.out.println("我成功了");
                System.out.println("Crawling URL: " + url);
                WebPageCrawler crawler = new WebPageCrawler(url);
                List<String>subPages = crawler.crawl(); 
                
                tree.setPostOrderScore(keywordList);
               
                //檢查子網頁是否有成功抓取
                if (subPages.isEmpty()) {
                    System.out.println("No subpages found for URL: " + url);
                } else {
                    System.out.println("Total SubPages for URL: " + url + " -> " + subPages.size());
                    for (String suburl : subPages) {
                        System.out.println("SubPage: " + suburl);
                    }
                }
                
                //把子網頁和主網頁建成樹
                for(String suburl:subPages) {
               	 System.out.println("Adding SubPage: " + suburl);
               	 String content = gq.getContent(); // 获取子页面内容
                 rootpage.setContent(content); // 更新内容
                 rootpage.setScore(keywordList); // 使用关键字列表计算分数
               	 WebPage subpage = new WebPage(suburl,title);
               	 WebNode subnode = new WebNode(subpage);
               	 root.addChild(subnode);
               	 subpage.setContent(content); // 更新内容
                 subpage.setScore(keywordList); // 使用关键字列表计算分数
               	 System.out.println("分數：" + subnode.getScore());
                }
                System.out.println("SubPages added for URL: " + url + ", Total Children: " + root.children.size());
                //tree.eularPrintTree();
                tree.setPostOrderScore(keywordList);
                
            }
       } 
       catch (Exception e) 
       {
           e.printStackTrace();
       }
   
	}
}