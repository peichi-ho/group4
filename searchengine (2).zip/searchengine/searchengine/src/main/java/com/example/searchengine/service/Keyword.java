package com.example.searchengine.service;

public class Keyword {
    public String name;
    public int count;
    public double weight;

    public Keyword(String name, int count, double weight) {
        this.name = name;
        this.count = count;
        this.weight = weight;
    }

    public String getName() {
        return name;
    }

    public int getCount() {
        return count;
    }

    public double getWeight() {
        return weight;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }
}
