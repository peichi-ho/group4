package com.example.searchengine.service;

import java.util.ArrayList;

public class SubPageCrawler {
    public ArrayList<WebPage> fetchSubPages(String parentUrl) {
        ArrayList<WebPage> subPages = new ArrayList<>();
        try {
            GoogleQuery query = new GoogleQuery(parentUrl); // 爬取該網頁的相關子頁
            ArrayList<String> subUrls = new ArrayList<>(query.query().values());
            
            int maxSubPages = 3; // 限制子網頁數量
            for (int i = 0; i < Math.min(maxSubPages, subUrls.size()); i++) {
                String subUrl = subUrls.get(i);
                subPages.add(new WebPage(subUrl, "SubPage " + (i + 1)));
            }
        } catch (Exception e) {
            System.err.println("Error fetching subpages for URL: " + parentUrl);
            e.printStackTrace();
        }
        return subPages;
    }
}
