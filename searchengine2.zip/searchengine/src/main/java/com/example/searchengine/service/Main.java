package com.example.searchengine.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Get user input for the search query
        Scanner sc = new Scanner(System.in);
        System.out.println("請輸入查詢關鍵字：");
        String keyword = "影視" + sc.nextLine();
        sc.close();

        // Define a list of keywords and their weights
        ArrayList<Keyword> keywords = new ArrayList<>();
        keywords.add(new Keyword("美劇", 4));
        keywords.add(new Keyword("日劇", 4));
        keywords.add(new Keyword("韓劇", 4));
        keywords.add(new Keyword("台劇", 4));
        keywords.add(new Keyword("陸劇", 4));
        keywords.add(new Keyword("音樂劇", 4));
        keywords.add(new Keyword("影評", 2));
        keywords.add(new Keyword("電影", 5));
        keywords.add(new Keyword("演員", 3));
        keywords.add(new Keyword("集數", 3));
        keywords.add(new Keyword("上映", 2));
        keywords.add(new Keyword("劇情", 2));
        keywords.add(new Keyword("影視", 5));
        keywords.add(new Keyword("IMDb", 5));
        keywords.add(new Keyword("豆瓣", 5));
        keywords.add(new Keyword("Rotten Tomatoes", 5));

        // Perform the search
        GoogleQuery gq = new GoogleQuery(keyword);
        HashMap<String, String> results;
        try {
            results = gq.query();
            if (results.isEmpty()) {
                System.out.println("GoogleQuery.query() 返回空結果，請檢查 HTML 解析邏輯。");
                return;
            } else {
                System.out.println("成功解析查詢結果：");
                results.forEach((key, value) -> System.out.println("標題：" + key + "，URL：" + value));
            }
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        // Create a root web page (query string as the name)
        WebPage rootPage = new WebPage("https://www.google.com/search?q=" + keyword, "查詢：" + keyword);
        WebTree tree = new WebTree(rootPage);

        // Add search results as child nodes
        for (Map.Entry<String, String> entry : results.entrySet()) {
            String title = entry.getKey();
            String url = entry.getValue();

            WebPage page = new WebPage(url, title);
            WebNode node = new WebNode(page);
            tree.root.addChild(node);
            System.out.println("已添加節點 - 標題：" + title + "，URL：" + url);

            // Fetch and add children nodes
            try {
                node.fetchAndAddChildren(keywords);
            } catch (IOException e) {
                System.out.println("Failed to fetch children for: " + title);
            }
        }

        // Calculate scores (post-order traversal)
        try {
            tree.setPostOrderScore(keywords);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Sort child nodes by score in descending order
        tree.root.children.removeIf(node -> node.nodeScore <= 0); // 過濾掉分數 <= 0 的節點
        tree.root.children.sort((o1, o2) -> Double.compare(o2.nodeScore, o1.nodeScore)); // 按分數降序排序

        // Output results
        System.out.println("搜尋結果（依影視相關度排序）：");
        for (WebNode child : tree.root.children) {
            System.out.println("標題：" + child.webPage.name);
            System.out.println("URL：" + child.webPage.url);
            System.out.println("分數：" + child.nodeScore);
            System.out.println("-----------------------");
        }
    }
}
