package com.example.searchengine.service;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;

public class WebNode {
    public WebNode parent;
    public ArrayList<WebNode> children;
    public WebPage webPage;
    public double nodeScore;

    public WebNode(WebPage webPage) {
        this.webPage = webPage;
        this.children = new ArrayList<>();
    }

    public void setNodeScore(ArrayList<Keyword> keywords) throws IOException {
        webPage.setScore(keywords); // 計算當前節點分數
        nodeScore = webPage.score;

        // 累積子節點分數
        for (WebNode child : children) {
            child.setNodeScore(keywords); // 遞迴計算子節點分數
            nodeScore += child.nodeScore * 0.5; // 子節點分數加權累積
        }
        System.out.println("[節點分數] " + webPage.name + " 總分數：" + nodeScore);
    }

    public void addChild(WebNode child) {
        this.children.add(child);
        child.parent = this;
    }

    /**
     * Fetch child nodes and set their scores, with a limit on the maximum number of child nodes.
     * 
     * @param keywords     The list of keywords for scoring.
     * @param maxChildren  The maximum number of child nodes to fetch.
     * @throws IOException If an error occurs during fetching or scoring.
     */
    public void fetchAndSetChildScores(ArrayList<Keyword> keywords, int maxChildren) throws IOException {
        if (webPage == null || maxChildren <= 0) return;

        // 使用 JSoup 解析主網頁的子連結
        Document doc = Jsoup.connect(webPage.url)
                .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36")
                .timeout(5000)
                .get();

        Elements links = doc.select("a[href]"); // 抓取所有超連結
        int count = 0;

        for (Element link : links) {
            if (count >= maxChildren) break; // 限制子節點數量
            String childUrl = link.absUrl("href");
            String childTitle = link.text();

            if (!childUrl.isEmpty() && !childTitle.isEmpty()) {
                WebPage childPage = new WebPage(childUrl, childTitle);
                WebNode childNode = new WebNode(childPage);
                this.addChild(childNode);

                // 設定子節點的分數
                childNode.setNodeScore(keywords);
                count++;
                System.out.println("Added Node: " + childTitle + " (" + childUrl + ")");
            }
        }
    }

    public void fetchAndAddChildren(ArrayList<Keyword> keywords) throws IOException {
        Document doc = Jsoup.connect(this.webPage.url)
                            .timeout(5000) // 增加超時設定
                            .userAgent("Mozilla/5.0")
                            .get();

        Elements links = doc.select("a[href]"); // 抓取所有超連結
        int maxChildren = 3; // 限制最多抓取的子節點數量
        int count = 0;

        for (Element link : links) {
            if (count >= maxChildren) break; // 限制子節點數量
            String childUrl = link.absUrl("href");
            String childTitle = link.text();

            // 過濾掉不相關的子網頁
            if (!childUrl.isEmpty() && !childTitle.isEmpty()) {
                WebPage childPage = new WebPage(childUrl, childTitle);
                WebNode childNode = new WebNode(childPage);
                this.addChild(childNode);

                // 設定子網頁的分數
                childNode.setNodeScore(keywords);
                count++;
                System.out.println("Added Node: " + childTitle + " (" + childUrl + ")");
            }
        }
    }

    public boolean isTheLastChild() {
        if (this.parent == null) return true;
        ArrayList<WebNode> siblings = this.parent.children;
        return this.equals(siblings.get(siblings.size() - 1));
    }

    public int getDepth() {
        int depth = 1;
        WebNode current = this;
        while (current.parent != null) {
            depth++;
            current = current.parent;
        }
        return depth;
    }
}
