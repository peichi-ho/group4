package com.example.searchengine.service;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class WordCounter {
    private String urlStr;
    private String content; // 用於存放淨化後的文本內容

    public WordCounter(String urlStr) {
        this.urlStr = urlStr;
    }

    private String fetchRawHTML() throws IOException {
        URL url = new URL(this.urlStr);
        URLConnection conn = url.openConnection();
        conn.setRequestProperty("User-Agent", 
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36");
        InputStream in = conn.getInputStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(in));

        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) {
            sb.append(line).append("\n");
        }
        return sb.toString();
    }

    private String cleanContent(String rawHtml) {
        Document doc = Jsoup.parse(rawHtml);

        // 移除 script, style, iframe
        doc.select("script, style, iframe").remove();

        // 移除廣告或不必要標籤，過濾 class 或 id 包含 'ad', 'news' 的元素
        doc.select("[class*=ad], [id*=ad]").remove(); // 移除廣告
        doc.select("div[class*=news], section[class*=news]").remove(); // 移除新聞相關

        // 回傳淨化後的純文字
        return doc.text();
    }

    private String fetchContent() {
        if (content != null) return content; // 若已抓取則不重複操作

        try {
            String rawHtml = fetchRawHTML();
            content = cleanContent(rawHtml); // 僅在第一次使用時抓取和清理
        } catch (IOException e) {
            System.out.println("Warning: Failed to fetch content from " + urlStr 
                               + ". Using empty content as fallback.");
            content = "";
        }
        return content;
    }

    public int countKeyword(String keyword) {
        if (content == null) {
            content = fetchContent();
        }

        if (content.isEmpty()) {
            // 若為空字串則無關鍵字
            return 0;
        }

        String upperContent = content.toUpperCase();
        String upperKeyword = keyword.toUpperCase();

        int retVal = 0;
        int fromIdx = 0;
        int found;
        while ((found = upperContent.indexOf(upperKeyword, fromIdx)) != -1) {
            retVal++;
            fromIdx = found + upperKeyword.length();
        }

        return retVal;
    }
}
