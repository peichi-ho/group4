package com.example.searchengine.service;

import java.io.IOException;
import java.util.ArrayList;


public class WebPage {
    public String url;
    public String name;
    public WordCounter counter;
    public double score;

    public WebPage(String url, String name){
        this.url = url;
        this.name = name;
        this.counter = new WordCounter(url);
    }

    public void setScore(ArrayList<Keyword> keywords) throws IOException {
        score = 0;
        String upperTitle = name.toUpperCase();
        boolean titleMatched = false;
    
        // 檢查標題是否包含關鍵字
        for (Keyword k : keywords) {
            if (upperTitle.contains(k.name.toUpperCase())) {
                double titleScore = 2 * k.weight;
                score += titleScore;
                titleMatched = true;
                System.out.println("[標題匹配] " + name + " 匹配關鍵字：" + k.name + "，分數增加：" + titleScore);
            }
        }
    
        // 如果標題匹配，增加大額獎勵分數
        if (titleMatched) {
            double bigBonus = 10000;
            score += bigBonus;
            System.out.println("[標題加分] " + name + " 獲得額外加分：" + bigBonus);
        }
    
        // 檢查內容是否包含關鍵字
        for (Keyword k : keywords) {
            int count = counter.countKeyword(k.name);
            if (count > 0) {
                double contentScore = count * k.weight;
                score += contentScore;
    
                // 增加細化條件：如果關鍵字出現頻率較高，給予額外分數
                if (count > 10) {
                    score += 50; // 額外加分
                    System.out.println("[高頻加分] " + name + " 關鍵字：" + k.name + " 出現次數：" + count + "，額外加分：50");
                }
    
                System.out.println("[內容匹配] " + name + " 匹配關鍵字：" + k.name + "，出現次數：" + count + "，分數增加：" + contentScore);
            }
        }
    }
    
    
}