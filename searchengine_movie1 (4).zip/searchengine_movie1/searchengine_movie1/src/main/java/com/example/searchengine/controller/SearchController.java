//處理與搜尋相關的前後端邏輯，將用戶的請求轉換為 HTML 頁面的回應
//提供一個搜尋介面（HTML 頁面）
package com.example.searchengine.controller;
import com.example.searchengine.service.Main; // 這是範例路徑，請依實際專案架構修改

import org.springframework.beans.factory.annotation.Autowired;

import com.example.searchengine.service.GoogleQuery;
import com.example.searchengine.service.Keyword;
import com.example.searchengine.service.KeywordList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

@Controller
public class SearchController {

    // 處理首頁，顯示搜尋表單
    @GetMapping("/")
    public String index() {
        return "index"; // 回傳 index.html
    }

    // 處理搜尋請求，顯示結果
    @GetMapping("/search")
    public String search(@RequestParam("query") String query, Model model) {
        try {
        	//將關鍵字傳遞給 GoogleQuery
        	 List<Keyword> keywords = new KeywordList().getKeywords(); // 獲取關鍵字列表
        	String modifiedQuery = query + " 電影"; 
            GoogleQuery googleQuery = new GoogleQuery(modifiedQuery);
            HashMap<String, String> results = googleQuery.query(keywords);

            model.addAttribute("query", query);
            model.addAttribute("results", results);

        } catch (IOException e) {
            model.addAttribute("error", "Error fetching search results. Please try again later.");
            e.printStackTrace();
        }

        return "result";
    }

}
