package com.example.searchengine.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import java.util.ArrayList;

import java.io.IOException;

import java.util.Scanner;
import java.util.List;
import java.util.HashMap;
import java.util.LinkedHashMap;
import com.example.searchengine.service.GoogleSearchService;

@Service
public class Main 
{
    public static void main(String[] args) 
    {
    	Scanner sc = new Scanner(System.in);
		ArrayList keywordArraylist = new ArrayList();
	    KeywordList keywordList = new KeywordList();
	    System.out.println("請輸入查詢關鍵字：");
	    String keyword = sc.nextLine();
	    Keyword userKeyword = new Keyword(keyword, 0, 10); 
	    keywordList.add(userKeyword);
	    keywordArraylist = keywordList.getKeywords();
	    GoogleQuery gq = new GoogleQuery(keyword);
        
    }
}
