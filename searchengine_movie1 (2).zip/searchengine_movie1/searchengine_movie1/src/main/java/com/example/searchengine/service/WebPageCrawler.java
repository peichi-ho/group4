package com.example.searchengine.service;

public class WebPageCrawler {

}
