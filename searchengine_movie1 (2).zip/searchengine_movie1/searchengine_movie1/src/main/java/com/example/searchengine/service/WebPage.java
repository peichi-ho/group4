package com.example.searchengine.service;

import java.util.List;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ArrayList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class WebPage {
    private String url;
    private String name;
    private String content; // 儲存頁面內容
    private double score;   // 儲存分數

    public WebPage(String url, String name, String content) {
        this.url = url;
        this.name = name;
        this.score = 0.0; // 初始分數
    }

    public String getUrl() {
        return url;
    }

    public String getName() {
        return name;
    }

    public double getScore() {
        return score;
    }
    
    //抓取子網頁
    private double fetchAndScoreSubPages(List<Keyword> keywords) throws IOException {
        double totalSubPageScore = 0;

        // 1. 使用 Jsoup 抓取主網頁內容
        Document doc = Jsoup.connect(this.url).get();
        
        // 2. 挑選出子網頁的連結(這是設計上的一個定義，例如所有 <a> 標籤且 href 屬性為同網域的連結)
        Elements links = doc.select("a[href]");
        for (Element link : links) {
            String subUrl = link.absUrl("href");
            if (isSubPage(subUrl)) {  // 這個方法需要你定義，判斷是不是子頁面
                // 3. 抓取子網頁內容並計分
                double childScore = calculateSubPageScore(subUrl, keywords);
                totalSubPageScore += childScore;
            }
        }

        return totalSubPageScore;
    }
    private boolean isSubPage(String subUrl) throws MalformedURLException{
        try {
            URL main = new URL(this.url);
            URL child = new URL(subUrl);

            // 若子頁面的 host 與主頁面的 host 相同，視為子頁面
            return main.getHost().equalsIgnoreCase(child.getHost());
        } catch (MalformedURLException e) {
            // 若 URL 格式錯誤，視為不是子頁面
            return false;
        }
    }

    
    
    
    //這邊要計算到所有子網頁的分數
    public void setScore(List<Keyword> keywords) {
    	 for (Keyword keyword : keywords) {
             int count = countOccurrences(keyword.getName());
             score += count * keyword.getWeight(); // 分數公式
         }
    }

    /**
     * 計算分數：根據關鍵字出現次數和權重
     * @param keywords 傳入關鍵字列表
     */
   

    /**
     * 計算內容中某個關鍵字的出現次數
     * @param keyword 關鍵字
     * @return 出現次數
     */
    private int countOccurrences(String keyword) {
        if (content == null || keyword == null || keyword.isEmpty()) return 0;
        String lowerKeyword = keyword.toLowerCase(); // 關鍵字也轉小寫
        return (content.length() - content.replace(lowerKeyword, "").length()) / lowerKeyword.length();
    }
}
