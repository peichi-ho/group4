package com.example.searchengine.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // 取得使用者輸入的查詢關鍵字
        Scanner sc = new Scanner(System.in);
        System.out.println("請輸入查詢關鍵字：");
        String keyword = sc.nextLine();
        sc.close();

        // 定義影視相關關鍵字與權重
        // 以下舉例
        ArrayList<Keyword> keywords = new ArrayList<>();
        keywords.add(new Keyword("美劇", 4));
        keywords.add(new Keyword("日劇", 4));
        keywords.add(new Keyword("韓劇", 4));
        keywords.add(new Keyword("台劇", 4));
        keywords.add(new Keyword("陸劇", 4));
        keywords.add(new Keyword("音樂劇", 4));
        keywords.add(new Keyword("影評", 2));
        keywords.add(new Keyword("電影", 5));
        keywords.add(new Keyword("演員", 3));
        keywords.add(new Keyword("集數", 3));
        keywords.add(new Keyword("上映日期", 2));
        keywords.add(new Keyword("劇情大綱", 2));
        keywords.add(new Keyword("影視作品", 5));
        keywords.add(new Keyword("IMDb", 5));
        keywords.add(new Keyword("豆瓣", 5));
        keywords.add(new Keyword("Rotten Tomatoes", 5));

        // 進行搜尋
        GoogleQuery gq = new GoogleQuery(keyword);
        HashMap<String, String> results;
        try {
            results = gq.query();
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        // 建立一個 root 網頁（不一定有實際 URL，就用查詢字串當作名稱）
        WebPage rootPage = new WebPage("https://www.google.com/search?q="+keyword, "查詢：" + keyword);
        WebTree tree = new WebTree(rootPage);

        // 將搜尋結果加入為子節點
        for (Map.Entry<String, String> entry : results.entrySet()) {
            String title = entry.getKey();
            String url = entry.getValue();
            WebPage page = new WebPage(url, title);
            WebNode node = new WebNode(page);
            tree.root.addChild(node);
        }

        // 計算分數（後序遍歷）
        try {
            tree.setPostOrderScore(keywords);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // 按照分數排序子節點，分數高的在前
        Collections.sort(tree.root.children, new Comparator<WebNode>() {
            @Override
            public int compare(WebNode o1, WebNode o2) {
                return Double.compare(o2.nodeScore, o1.nodeScore); // 降冪排序
            }
        });

        // 輸出結果
        System.out.println("搜尋結果（依影視相關度排序）：");
        for (WebNode child : tree.root.children) {
            System.out.println("標題：" + child.webPage.name);
            System.out.println("URL：" + child.webPage.url);
            System.out.println("分數：" + child.nodeScore);
            System.out.println("-----------------------");
        }

        // 若要顯示樹狀結構（可選）
        // tree.eularPrintTree();
    }
}