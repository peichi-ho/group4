package com.example.searchengine.service;

import java.io.IOException;
import java.util.ArrayList;


public class WebPage {
    public String url;
    public String name;
    public WordCounter counter;
    public double score;

    public WebPage(String url, String name){
        this.url = url;
        this.name = name;
        this.counter = new WordCounter(url);
    }

    public void setScore(ArrayList<Keyword> keywords) throws IOException {
        score = 0;
        String upperTitle = name.toUpperCase();
        boolean titleMatched = false;

        // 檢查標題
        for (Keyword k : keywords) {
            if (upperTitle.contains(k.name.toUpperCase())) {
                double titleScore = 2 * k.weight;
                score += titleScore;
                titleMatched = true;
                System.out.println("[Title Match] " + name + " matched keyword: " + k.name + ", added: " + titleScore);
            }
        }

        if (titleMatched) {
            // 若標題有關鍵字匹配，給予巨額獎勵分數確保排序靠前
            double bigBonus = 10000;
            score += bigBonus;
            System.out.println("[Title Bonus] " + name + " received a title bonus of " + bigBonus);
        } else {
            // 若標題無相關關鍵字，依內容計分
            for (Keyword k : keywords) {
                int count = counter.countKeyword(k.name);
                if (count > 0) {
                    double contentScore = count * k.weight;
                    score += contentScore;
                    System.out.println("[Content Match] " + name + " matched keyword: " + k.name + ", count: " + count + ", added: " + contentScore);
                }
            }
        }
    }
}