package com.example.searchengine.service;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.jsoup.nodes.Element;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class WordCounter {
    private String urlStr;
    private String content; // 用於存放淨化後的文本內容

    public WordCounter(String urlStr) {
        this.urlStr = urlStr;
    }

    // 抓取原始 HTML
    private String fetchRawHTML() throws IOException {
        URL url = new URL(this.urlStr);
        URLConnection conn = url.openConnection();
        conn.setRequestProperty("User-Agent", 
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36");
        InputStream in = conn.getInputStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(in));

        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) {
            sb.append(line).append("\n");
        }
        return sb.toString();
    }

    // 清除廣告與不必要標籤，取得淨化後文本
    private String cleanContent(String rawHtml) {
        // 使用 Jsoup 解析
        Document doc = Jsoup.parse(rawHtml);

        // 移除 script, style, iframe
        doc.select("script, style, iframe").remove();

        // 移除 class 或 id 中包含 'ad' 的元素，您可依需求加強選擇器
        Elements adElements = doc.select("[class*=ad], [id*=ad]");
        for (Element adElement : adElements) {
            adElement.remove();
        }

        // 回傳淨化後的純文字
        return doc.text();
    }

    private String fetchContent() {
        try {
            String rawHtml = fetchRawHTML();
            return cleanContent(rawHtml);
        } catch (IOException e) {
            // 若抓取失敗，回傳空字串避免計分發生錯誤
            System.out.println("Warning: Failed to fetch content from " + urlStr 
                               + ". Using empty content as fallback.");
            return "";
        }
    }

    public int countKeyword(String keyword) {
        if (content == null) {
            content = fetchContent();
        }

        if (content.isEmpty()) {
            // 若為空字串則無關鍵字
            return 0;
        }

        String upperContent = content.toUpperCase();
        String upperKeyword = keyword.toUpperCase();

        int retVal = 0;
        int fromIdx = 0;
        int found;
        while ((found = upperContent.indexOf(upperKeyword, fromIdx)) != -1) {
            retVal++;
            fromIdx = found + upperKeyword.length();
        }

        return retVal;
    }
}
