package com.example.searchengine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SearchEngineApplicationTests {

	@Test
	void contextLoads() {
	}

}
