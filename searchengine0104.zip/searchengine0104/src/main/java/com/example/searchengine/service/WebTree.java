package com.example.searchengine.service;

import java.io.IOException;
import java.util.ArrayList;

public class WebTree {
	public WebNode root;

	public WebTree(WebPage rootPage) {
		this.root = new WebNode(rootPage);
	}

	public void setPostOrderScoreWithChildren(ArrayList<Keyword> keywords) throws IOException {
		setPostOrderScoreWithChildren(root, keywords);
	}

	private void setPostOrderScoreWithChildren(WebNode startNode, ArrayList<Keyword> keywords) throws IOException {
		for (WebNode child : startNode.children) {
			setPostOrderScoreWithChildren(child, keywords);
		}
		startNode.setNodeScore(keywords); // 父節點分數包含所有子節點
		System.out.println("Node Score for: " + startNode.webPage.name + " (" + startNode.webPage.url + ") = "
				+ startNode.nodeScore);
	}

	public WebNode getRoot() {
		return root;
	}

}
