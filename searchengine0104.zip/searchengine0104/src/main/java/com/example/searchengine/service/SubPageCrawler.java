package com.example.searchengine.service;

import java.util.ArrayList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class SubPageCrawler {
    public ArrayList<WebPage> fetchSubPages(String parentUrl) {
    ArrayList<WebPage> subPages = new ArrayList<>();
    try {
        // 使用 Jsoup 直接解析該 URL
        Document doc = Jsoup.connect(parentUrl).get();
        Elements links = doc.select("a[href]"); // 提取所有的 <a> 標籤連結

        int maxSubPages = 3; // 限制子網頁數量
        for (Element link : links) {
            String subUrl = link.attr("abs:href");
            subPages.add(new WebPage(subUrl, link.text()));
            if (subPages.size() >= maxSubPages) break;
        }
    } catch (Exception e) {
        System.err.println("Error fetching subpages for URL: " + parentUrl);
        e.printStackTrace();
    }
    return subPages;
}

}
