package com.example.searchengine.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class GoogleQuery {

    public String searchKeyword;
    public String url;
    public String content;

    public GoogleQuery(String searchKeyword) {

        this.searchKeyword = searchKeyword;
        try {
            String encodeKeyword = java.net.URLEncoder.encode(searchKeyword, "utf-8");
            this.url = "https://www.google.com/search?q=" + encodeKeyword + "影視&num=20";
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private String fetchContent() throws IOException {
        try {
            URL u = new URL(url);
            URLConnection conn = u.openConnection();
            conn.setRequestProperty("User-agent", "Chrome/107.0.5304.107");
            InputStream in = conn.getInputStream();

            BufferedReader reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
            StringBuilder content = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                content.append(line);
            }
            reader.close();

            return content.toString();
        } catch (IOException e) {
            if (e.getMessage().contains("Server returned HTTP response code: 429")) {
                System.err.println("Too Many Requests: Retrying after delay...");
                try {
                    Thread.sleep((long) (Math.random() * 3000) + 2000); // 延遲 5 秒後重試
                } catch (InterruptedException ie) {
                    System.err.println("Thread interrupted during sleep.");
                    Thread.currentThread().interrupt(); // 恢復中斷狀態
                }
                return fetchContent(); // 再次嘗試請求
            } else {
                throw e; // 其他異常則拋出
            }
        }
    }

    public HashMap<String, String> query() throws IOException {
        if (content == null) {
            content = fetchContent();
        }

        HashMap<String, String> retVal = new HashMap<String, String>();

        // using Jsoup analyze html string
        Document doc = Jsoup.parse(content);

        // select particular element(tag) which you want
        Elements lis = doc.select("div");
        lis = lis.select(".kCrYT");

        for (Element li : lis) {
            try {
                String citeUrl = li.select("a").get(0).attr("href").replace("/url?q=", "").split("&")[0];
                String title = li.select("a").get(0).select(".vvjwJb").text();

                if (title.equals("")) {
                    continue;
                }

                System.out.println("Title: " + title + " , url: " + citeUrl);

                // put title and pair into HashMap
                retVal.put(title, citeUrl);

            } catch (IndexOutOfBoundsException e) {
                // e.printStackTrace();
            }
        }

        return retVal;
    }

    public HashMap<String, String> getRelatedQueries() throws IOException {
        if (content == null) {
            content = fetchContent();
        }

        HashMap<String, String> relatedQueries = new HashMap<>();

        // 使用 Jsoup 分析 HTML 字串
        Document doc = Jsoup.parse(content);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("output.html"))) {
            writer.write(doc.html());
            System.out.println("HTML content has been written to output.html");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // 選取包含相關搜尋關鍵字的區塊
        Elements relatedElements = doc.select(".Xe4YD");

        for (Element element : relatedElements) {
            try {
                String keyword = element.text();
                String link = "http://localhost:8081/search?query=" + keyword;

                if (!keyword.isEmpty() && !link.isEmpty()) {
                    relatedQueries.put(keyword, link);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (relatedQueries.isEmpty()) {
            // 若抓不到關鍵字，使用預設的關鍵字後綴生成相關關鍵字
            ArrayList<String> commonSuffixes = new ArrayList<>();
            commonSuffixes.add("影評");
            commonSuffixes.add("線上看");
            commonSuffixes.add("介紹");
            commonSuffixes.add("電影");
            commonSuffixes.add("演員");

            // 循環生成新的關鍵字
            for (String suffix : commonSuffixes) {
                String newKeyword = searchKeyword + suffix;
                String newLink = "http://localhost:8081/search?query=" + newKeyword;
                relatedQueries.put(newKeyword, newLink);
            }
        }

        return relatedQueries;
    }

}
