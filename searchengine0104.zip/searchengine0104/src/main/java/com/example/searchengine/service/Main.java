package com.example.searchengine.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("請輸入查詢關鍵字：");
        String keyword = sc.nextLine();
        sc.close();
        try {
            // System.out.println(new GoogleQuery(keyword).query());
            // System.out.println(new GoogleQuery(keyword).getRelatedQueries());
            GoogleQuery googleQuery = new GoogleQuery(keyword);

            // 查詢主要結果
            HashMap<String, String> queryResults = googleQuery.query();
            System.out.println("查詢結果：");
            for (String title : queryResults.keySet()) {
                System.out.println("標題：" + title);
            }

            // 查詢相關搜尋
            HashMap<String, String> relatedQueries = googleQuery.getRelatedQueries();
            System.out.println("\n相關搜尋關鍵字：");
            if (relatedQueries.isEmpty()) {
                System.out.println("EMPTY!!!!!!!!");
            }
            for (String relatedKeyword : relatedQueries.keySet()) {
                System.out.println("關鍵字：" + relatedKeyword + "，連結：" + relatedQueries.get(relatedKeyword));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
