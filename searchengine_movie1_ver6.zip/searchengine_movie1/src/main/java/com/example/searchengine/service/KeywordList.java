package com.example.searchengine.service;

import java.util.ArrayList;

public class KeywordList {
    private ArrayList<Keyword> keywords;
    

    public KeywordList() {
        this.keywords = new ArrayList<>();
     // 關鍵字與權重
        ArrayList<Keyword> keywords = new ArrayList<>();
        keywords.add(new Keyword("美劇", 0, 4));
        keywords.add(new Keyword("日劇", 0, 4));
        keywords.add(new Keyword("韓劇", 0, 4));
        keywords.add(new Keyword("台劇", 0, 4));
        keywords.add(new Keyword("陸劇", 0, 4));
        keywords.add(new Keyword("影評", 0, 2));
        keywords.add(new Keyword("電影", 0, 5));
        keywords.add(new Keyword("演員", 0, 3));
        keywords.add(new Keyword("集數", 0, 3));
        keywords.add(new Keyword("動作片", 0, 5));
        keywords.add(new Keyword("愛情片", 0, 5));
        keywords.add(new Keyword("評分", 0, 4));
        keywords.add(new Keyword("票房", 0, 3));
        keywords.add(new Keyword("上映日期", 0, 2));
        keywords.add(new Keyword("劇情大綱", 0, 2));
        keywords.add(new Keyword("影視作品", 0, 5));
        keywords.add(new Keyword("IMDb", 0, 5));
        keywords.add(new Keyword("豆瓣", 0, 5));
        keywords.add(new Keyword("Rotten Tomatoes", 0, 5));

    }

    public void add(Keyword keyword) {
        keywords.add(keyword);
    }

    public ArrayList<Keyword> getKeywords() {
        return keywords;
    }
}
