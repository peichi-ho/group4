package com.example.searchengine.service;

import java.util.List;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ArrayList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class WebPage {
    private String url;
    private String name;
    private String content; // 儲存頁面內容
    private double score;   // 儲存分數

    //給主網頁
    public WebPage(String url,String name) {
        this.url = url;
        this.name = name;
        this.score = 0.0;
    }
    //給子網頁
    public WebPage(String url) {
        this.url = url;
        this.score = 0.0;
    }

    public String getUrl() {
        return url;
    }

    public String getName() {
        return name;
    }

    public double getScore() {
        return score;
    }
    
    //這邊要計算到所有子網頁的分數
    public void setScore(List<Keyword> keywords) {
    	 for (Keyword keyword : keywords) {
             int count = countOccurrences(keyword.getName());
             score += count * keyword.getWeight(); // 分數公式
         }
    }

    private int countOccurrences(String keyword) {
        if (content == null || keyword == null || keyword.isEmpty()) return 0;
        String lowerKeyword = keyword.toLowerCase(); // 關鍵字也轉小寫
        return (content.length() - content.replace(lowerKeyword, "").length()) / lowerKeyword.length();
    }
}
