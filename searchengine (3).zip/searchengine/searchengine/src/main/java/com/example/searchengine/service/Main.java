package com.example.searchengine.service;

import java.io.IOException;
import java.util.Scanner;

import com.example.searchengine.controller.SearchController;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class Main 
{
    public static void main(String[] args) 
    {
    Scanner sc = new Scanner(System.in);
   
    KeywordList keywords=new KeywordList();
    System.out.println("Hello");
    System.out.println("請輸入查詢關鍵字：");
    String keyword = sc.nextLine();
    String modifiedKeyword = keyword + " 電影"; 
    Keyword userKeyword = new Keyword(modifiedKeyword, 0, 10);
    keywords.add(userKeyword);
    //GoogleSearchService googleSearchService=new GoogleSearchService();
   // SearchController searchController=new SearchController(googleSearchService);
    //searchController.search(keyword, null);

        try 
        {
        	System.out.println("敏柔加油");
        	GoogleQuery gq = new GoogleQuery(modifiedKeyword);
            // 呼叫 query 方法，假設 query 需要傳入 KeywordList 中的 keywords
            //HashMap<String, String> results = gq.query(keywordList.getKeywords());
            HashMap<String, String> results = gq.query();  
            
            System.out.println("Number of results from GoogleQuery: " + results.size());
            
            List<WebNode> roots = new ArrayList<>();
            List<String> urlList = new ArrayList<>(results.values());
            List<String> nameList = new ArrayList<>(results.keySet());
            
           
            for(String url : urlList) {
           	 int index =  urlList.indexOf(url);
           	 String title = nameList.get(index);
           	 	//主網頁
           	 	WebPage rootpage = new WebPage(url,title);
                WebNode root = new WebNode(rootpage);
                roots.add(root);
                WebTree tree = new WebTree(root);
                String content = gq.getContent(); // 获取子页面内容
                if (content != null && !content.isEmpty()) {
                    rootpage.setContent(content);
                    rootpage.setScore(keywords.getKeywords());
                } else {
                    System.out.println("Failed to fetch content for Root URL: " + url);
                    continue; // 跳过无效的网页
                }
                //下一步要爬子網頁
                System.out.println("我成功了");
                System.out.println("Crawling URL: " + url);
                WebPageCrawler crawler = new WebPageCrawler(url);
                List<String>subPages = crawler.crawl(); 
                
                
               
                //檢查子網頁是否有成功抓取
                if (subPages.isEmpty()) {
                    System.out.println("No subpages found for URL: " + url);
                } else {
                    System.out.println("Total SubPages for URL: " + url + " -> " + subPages.size());
                    for (String suburl : subPages) {
                        System.out.println("SubPage: " + suburl);
                    }
                }
                
                //把子網頁和主網頁建成樹
                for(String suburl:subPages) {
               	 System.out.println("Adding SubPage: " + suburl);
               	 
               	 WebPage subpage = new WebPage(suburl,title);
               	 WebNode subnode = new WebNode(subpage);
               	 for(String subContent:crawler.crawl()) {
               	   if (subContent != null && !subContent.isEmpty()) {
                       subpage.setContent(subContent);
                       subpage.setScore(keywords.getKeywords());
                   } else {
                       System.out.println("Failed to fetch content for SubPage: " + suburl);
                   }
               	 }
               	
               	 root.addChild(subnode);
               	 subpage.setContent(content); // 更新内容
                 subpage.setScore(keywords.getKeywords()); // 使用关键字列表计算分数
               	 System.out.println("分數：" + subnode.getScore());
                }
                System.out.println("SubPages added for URL: " + url + ", Total Children: " + root.children.size());
                //tree.eularPrintTree();
                tree.setPostOrderScore(keywords.getKeywords());
                System.out.println("Tree score for URL: " + url + " -> " + root.score);
            }
            List<WebPage> allWebPages = new ArrayList<>();
            for (WebNode root : roots) {
                allWebPages.add(root.webPage); // 添加主网页
                for (WebNode child : root.children) {
                    allWebPages.add(child.webPage); // 添加子网页
                }
            }

            // 对所有网页按照分数降序排序
            Collections.sort(allWebPages);

            // 打印排序结果
            System.out.println("Sorted WebPages by Score:");
            for (WebPage page : allWebPages) {
                System.out.println("Name: " + page.getName() + " | Score: " + page.getScore());
            }

       } 
       catch (Exception e) 
       {
           e.printStackTrace();
       }
   
	}
}