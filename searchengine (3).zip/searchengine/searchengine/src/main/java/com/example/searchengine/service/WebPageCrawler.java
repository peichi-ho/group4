package com.example.searchengine.service;
import java.io.IOException;             // 處理可能拋出的 IO 異常
import java.util.ArrayList;            // 用於定義和操作 ArrayList
import java.util.List;                 // 定義返回的 List 結構

import org.jsoup.Jsoup;                // 用於從 URL 抓取和解析 HTML
import org.jsoup.nodes.Document;       // 表示 HTML 文檔的 Jsoup 類
import org.jsoup.nodes.Element;        // 表示 HTML 標籤的 Jsoup 類
import org.jsoup.select.Elements;      // 表示多個 Element 的集合
import java.util.Collections;


public class WebPageCrawler {
	public String url;//這是主網頁
	public WebPageCrawler(String url) {
        this.url = url;
    }
	public List<String> crawl() throws IOException {
        List<String> subPageUrls = new ArrayList<>();
        try {
            System.out.println("Crawling URL: " + url);
            Document doc = Jsoup.connect(url).get();
            Elements links = doc.select("a[href]");
            System.out.println("Found " + links.size() + " links on page: " + url);

            for (Element link : links) {
                String subPageUrl = link.attr("abs:href");
                if (subPageUrl.startsWith("http")) { // 篩選條件
                    subPageUrls.add(subPageUrl);
                }
            }
            System.out.println("Filtered SubPage URLs: " + subPageUrls.size());
        } catch (IOException e) {
            System.err.println("Failed to fetch content from URL: " + url);
            e.printStackTrace();
            return Collections.emptyList(); // 返回空列表
        }
        return subPageUrls;
    }
}
