//處理與搜尋相關的前後端邏輯，將用戶的請求轉換為 HTML 頁面的回應
//提供一個搜尋介面（HTML 頁面）
package com.example.searchengine.controller;
import com.example.searchengine.service.GoogleQuery;
import com.example.searchengine.service.GoogleSearchService;
import com.example.searchengine.service.Keyword;
import com.example.searchengine.service.KeywordList;
import com.example.searchengine.service.WebNode;
import com.example.searchengine.service.WebPage;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.stereotype.Service;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class SearchController {
	private final GoogleSearchService googleSearchService;
	public SearchController(GoogleSearchService googleSearchService) {
		this.googleSearchService=googleSearchService;
	}
    
	// 處理首頁，顯示搜尋表單
    @GetMapping("/")
    public String index() {
        return "index"; // 回傳 index.html
    }

    // 處理搜尋請求，顯示結果
    @GetMapping("/search")
    public String search(@RequestParam("query") String query, Model model) {
        try {
        	//將關鍵字傳遞給 GoogleQuery
        	
        	String modifiedQuery = query + " 電影"; 
        	System.out.println("Modified Query: " + modifiedQuery);
            GoogleQuery googleQuery = new GoogleQuery(modifiedQuery);
            HashMap<String, String> results = googleQuery.query();
            
            // 將 HashMap 轉換為 WebNode 列表
            List<WebNode> webNodes = new ArrayList<>();
            for (Map.Entry<String, String> entry : results.entrySet()) {
                String pageTitle = entry.getKey();
                String pageUrl = entry.getValue();
                WebPage webPage = new WebPage(pageUrl, pageTitle);
                WebNode webNode = new WebNode(webPage);
                webNodes.add(webNode);
            }
         

            model.addAttribute("query", query);
            model.addAttribute("results", webNodes);
           


        } catch (IOException e) {
            model.addAttribute("error", "Error fetching search results. Please try again later.");
            e.printStackTrace();
        }

        return "result";
    }

}
