package com.example.searchengine.service;

import java.util.List;

public class WebPage implements Comparable<WebPage>{
    public String url;
    public String name;
    public String content; 
    public double score;   

    public WebPage(String url, String name) {
        this.url = url;
        this.name = name;
        this.score = 0.0; 
        this.content="";
    }

    public String getUrl() {
        return url;
    }

    public String getName() {
        return name;
    }

    public double getScore() {
        return score;
    }

    public void setScore(List<Keyword> keywords) {
    	 System.out.println("Calculating score for WebPage: " + name);
    	 for (Keyword keyword : keywords) {
             int count = countOccurrences(keyword.getName());
             score += count * keyword.getWeight(); 
            // System.out.println("Keyword: " + keyword.getName() + " | Count: " + count 
                  //   + " | Weight: " + keyword.getWeight() 
                   //  + " | Partial Score: " + score);
  
         }
    }
    public void setContent(String content) {
        this.content = content;
        System.out.println("Content set for WebPage: " + name + " | Content preview: " 
                           + content.substring(0, Math.min(100, content.length())) + "...");
    }

    /**
     * 計算分數：根據關鍵字出現次數和權重
     * @param keywords 傳入關鍵字列表
     */
   

    /**
     * 計算內容中某個關鍵字的出現次數
     * @param keyword 關鍵字
     * @return 出現次數
     */
    private int countOccurrences(String keyword) {
        if (content == null || keyword == null || keyword.isEmpty()) {
        	System.out.println("Content or keyword is null/empty. Returning 0.");
        	return 0;
        }
        String lowerContent = content.toLowerCase(); 
        String lowerKeyword = keyword.toLowerCase(); // 關鍵字也轉小寫
        int count =content.length() - content.replace(lowerKeyword, "").length()/ lowerKeyword.length();
        //System.out.println("Checking occurrences of keyword: '" + lowerKeyword + "' in content: '" 
                //+ lowerContent.substring(0, Math.min(100, lowerContent.length())) + "...'");
       // System.out.println("Occurrences found: " + count);
        return count;
    }
    @Override
    public int compareTo(WebPage other) {
        // 降序排序：分数高的在前
        return Double.compare(other.score, this.score);
    }
}
