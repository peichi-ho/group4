package com.example.searchengine.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;

public class WebTree {
    private WebNode root;
    public double rootscore;
    public WebTree(WebNode root) {
        this.root = root;
        this.rootscore = 0;
    }
    public void eularPrintTree(){
		eularPrintTree(root);
		if (root != null && root.webPage != null) {
	        System.out.println("Root Page: " + root.webPage.getName()+", Score: " + root.getScore());
	    } else {
	        System.out.println("Root is null or root webPage is null.");
	    }
	}
    private void eularPrintTree(WebNode startNode){
		int nodeDepth = startNode.getDepth();

		if (nodeDepth > 1)
			System.out.print("\n" + repeat("\t", nodeDepth - 1));

		System.out.print("(");
		System.out.print(startNode.webPage.getName() + "," + startNode.score);
		
		// YOUR TURN
		// 4. print child via pre-order
		for(WebNode child:startNode.children) {
			eularPrintTree(child);
		}
		System.out.print(")");

		if (startNode.isTheLastChild())
			System.out.print("\n" + repeat("\t", nodeDepth - 2));
	}

	private String repeat(String str, int repeat){
		String retVal = "";
		for (int i = 0; i < repeat; i++){
			retVal += str;
		}
		return retVal;
	}
	public void setPostOrderScore(ArrayList<Keyword> keywords) throws IOException{
		setPostOrderScore(root, keywords);
		this.rootscore = root.getScore();
		System.out.println(Double.toString(this.rootscore));
	}

	void setPostOrderScore(WebNode startNode,ArrayList<Keyword> keywords) throws IOException{
		
		startNode.setNodeScore(keywords);

	}

    public WebNode getRoot() {
        return root;
    }
}
