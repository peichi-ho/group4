package com.example.searchengine.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;

public class WebNode {
	public WebNode parent;
    public WebPage webPage;
    public double score;
    public ArrayList<WebNode> children;

    public WebNode(WebPage webPage) {
        this.webPage = webPage;
        this.children = new ArrayList<>();
    }

    public void addChild(WebNode child) {
    	this.children.add(child);
		child.parent = this;    
	}
    public boolean isTheLastChild(){
		if (this.parent == null)
			return true;
		ArrayList<WebNode> siblings = this.parent.children;

		return this.equals(siblings.get(siblings.size() - 1));
	}
    
    public ArrayList<WebNode> getChildren() {
        return children;
    }

    public void setNodeScore(ArrayList<Keyword> keywords) {
		
		webPage.setScore(keywords);
		score=webPage.score;
		
		for(WebNode child: children) {
			score+=child.score;

		}
		
		   

		
	}
    
    public double getScore() {
        return webPage.getScore();
    }
    
    public int getDepth(){
		int retVal = 1;
		WebNode currNode = this;
		while (currNode.parent != null)
		{
			retVal++;
			currNode = currNode.parent;
		}
		return retVal;
	}
}
