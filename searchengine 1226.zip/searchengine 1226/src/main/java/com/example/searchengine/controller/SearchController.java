package com.example.searchengine.controller;

import com.example.searchengine.service.GoogleQuery;
import com.example.searchengine.service.Keyword;
import com.example.searchengine.service.KeywordList;
import com.example.searchengine.service.SubPageCrawler;
import com.example.searchengine.service.WebNode;
import com.example.searchengine.service.WebPage;
import com.example.searchengine.service.WebTree;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.stream.Collectors;

@Controller
public class SearchController {

    // 處理首頁，顯示搜尋表單
    @GetMapping("/")
    public String index() {
        return "index"; // 回傳 index.html
    }

    // 處理搜尋請求，顯示結果
    /**
     * @param query
     * @param model
     * @return
     */
    @GetMapping("/search")
    public String search(@RequestParam("query") String query,
            @RequestParam(value = "addKeyword", defaultValue = "none") String addKeyword,
            Model model) {
        try {
            ArrayList<Keyword> keywordList = new ArrayList<>();
            keywordList.add(new Keyword("美劇", 4));
            keywordList.add(new Keyword("日劇", 4));
            keywordList.add(new Keyword("韓劇", 4));
            keywordList.add(new Keyword("台劇", 4));
            keywordList.add(new Keyword("陸劇", 4));
            keywordList.add(new Keyword("音樂劇", 4));
            keywordList.add(new Keyword("影評", 2));
            keywordList.add(new Keyword("電影", 5));
            keywordList.add(new Keyword("演員", 3));
            keywordList.add(new Keyword("集數", 3));
            keywordList.add(new Keyword("上映日期", 2));
            keywordList.add(new Keyword("劇情大綱", 2));
            keywordList.add(new Keyword("影視作品", 5));
            keywordList.add(new Keyword("IMDb", 5));
            keywordList.add(new Keyword("豆瓣", 5));
            keywordList.add(new Keyword("Rotten Tomatoes", 5));

            GoogleQuery googleQuery = new GoogleQuery(query);
            HashMap<String, String> results = googleQuery.query();

            ArrayList<WebTree> webTrees = new ArrayList<>();
            SubPageCrawler crawler = new SubPageCrawler();

            for (String title : results.keySet()) {
                String url = results.get(title);
                WebPage parentPage = new WebPage(url, title);

                WebTree webTree = new WebTree(parentPage);
                ArrayList<WebPage> subPages = crawler.fetchSubPages(url);

                for (WebPage subPage : subPages) {
                    webTree.root.addChild(new WebNode(subPage));
                }

                webTree.setPostOrderScoreWithChildren(keywordList); // 計算分數
                webTrees.add(webTree);
            }
            // webTree.eularPrintTree();
            // SearchController.java
            System.out.println("WebTree Results:");
            for (WebTree tree : webTrees) {
                System.out.println("Root: " + tree.getRoot().getWebPage().name);
                System.out.println("Self Score: " + tree.getRoot().getSelfScore()); // 父節點的自身分數
                System.out.println("Total Score: " + tree.getRoot().getNodeScore()); // 父節點的累加分數
                for (WebNode child : tree.getRoot().getChildren()) {
                    System.out.println("    Child: " + child.getWebPage().name);
                    System.out.println("    Child Self Score: " + child.getSelfScore()); // 子節點自身分數
                    System.out.println("    Child Total Score: " + child.getNodeScore()); // 子節點累加分數
                }
            }

            webTrees = (ArrayList<WebTree>) webTrees.stream()
                    .filter(t -> t.root.nodeScore >= 50 && t.root.getSelfScore() > 50)
                    .collect(Collectors.toList());

            // 排序 WebTree，依據分數由高到低
            if (webTrees.isEmpty()) {
                model.addAttribute("message", "No related result");
            } else {
                // 排序 WebTree，依據分數由高到低
                webTrees.sort((t1, t2) -> Double.compare(t2.root.nodeScore, t1.root.nodeScore));
                model.addAttribute("results", webTrees);
            }

            model.addAttribute("query", query);
            return "result";

        } catch (IOException e) {
            model.addAttribute("error", "Error fetching search results. Please try again later.");
            e.printStackTrace();
        }

        return "result";
    }

}
