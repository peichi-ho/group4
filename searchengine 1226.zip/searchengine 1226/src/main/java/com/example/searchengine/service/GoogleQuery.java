package com.example.searchengine.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class GoogleQuery {

    public String searchKeyword;
    public String url;
    public String content;

    public GoogleQuery(String searchKeyword) {

        this.searchKeyword = searchKeyword;
        try {
            // This part has been specially handled for Chinese keyword processing.
            // You can comment out the following two lines
            // and use the line of code in the lower section.
            // Also, consider why the results might be incorrect
            // when entering Chinese keywords.
            String encodeKeyword = java.net.URLEncoder.encode(searchKeyword, "utf-8");
            this.url = "https://www.google.com/search?q=" + encodeKeyword + "影視&oe=utf8&num=20";

            // this.url =
            // "https://www.google.com/search?q="+searchKeyword+"&oe=utf8&num=20";
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private String fetchContent() throws IOException {
        try {
            URL u = new URL(url);
            URLConnection conn = u.openConnection();
            conn.setRequestProperty("User-agent", "Chrome/107.0.5304.107");
            InputStream in = conn.getInputStream();

            BufferedReader reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
            StringBuilder content = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                content.append(line);
            }
            reader.close();

            return content.toString();
        } catch (IOException e) {
            if (e.getMessage().contains("Server returned HTTP response code: 429")) {
                System.err.println("Too Many Requests: Retrying after delay...");
                try {
                    Thread.sleep((long) (Math.random() * 3000) + 2000); // 延遲 5 秒後重試
                } catch (InterruptedException ie) {
                    System.err.println("Thread interrupted during sleep.");
                    Thread.currentThread().interrupt(); // 恢復中斷狀態
                }
                return fetchContent(); // 再次嘗試請求
            } else {
                throw e; // 其他異常則拋出
            }
        }
    }

    public HashMap<String, String> query() throws IOException {
        if (content == null) {
            content = fetchContent();
        }

        HashMap<String, String> retVal = new HashMap<String, String>();

        /*
         * some Jsoup source
         * https://jsoup.org/apidocs/org/jsoup/nodes/package-summary.html
         * https://www.1ju.org/jsoup/jsoup-quick-start
         */

        // using Jsoup analyze html string
        Document doc = Jsoup.parse(content);

        // select particular element(tag) which you want
        Elements lis = doc.select("div");
        lis = lis.select(".kCrYT"); // 如果提取结果为空，尝试调试HTML结构

        for (Element li : lis) {
            try {
                String citeUrl = li.select("a").get(0).attr("href").replace("/url?q=", "").split("&")[0];
                String title = li.select("a").get(0).select(".vvjwJb").text();

                if (title.equals("")) {
                    continue;
                }

                System.out.println("Title: " + title + " , url: " + citeUrl);

                // put title and pair into HashMap
                retVal.put(title, citeUrl);

            } catch (IndexOutOfBoundsException e) {
                // e.printStackTrace();
            }
        }

        return retVal;
    }
}
