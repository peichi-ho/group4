package com.example.searchengine.service;

import java.io.IOException;
import java.util.ArrayList;

public class WebTree {
	public WebNode root;

	public WebTree(WebPage rootPage) {
		this.root = new WebNode(rootPage);
	}

	public void setPostOrderScoreWithChildren(ArrayList<Keyword> keywords) throws IOException {
		setPostOrderScoreWithChildren(root, keywords);
	}

	private void setPostOrderScoreWithChildren(WebNode startNode, ArrayList<Keyword> keywords) throws IOException {
		for (WebNode child : startNode.children) {
			setPostOrderScoreWithChildren(child, keywords);
		}
		startNode.setNodeScore(keywords); // 父節點分數包含所有子節點
		System.out.println("Node Score for: " + startNode.webPage.name + " (" + startNode.webPage.url + ") = "
				+ startNode.nodeScore);
	}

	public WebNode getRoot() {
		return root;
	}

	// private void eularPrintTree(WebNode startNode){
	// int nodeDepth = startNode.getDepth();

	// if (nodeDepth > 1)
	// System.out.print("\n" + repeat("\t", nodeDepth - 1));

	// System.out.print("(");
	// System.out.print(startNode.webPage.name + "," + startNode.nodeScore);

	// // YOUR TURN
	// // 4. print child via pre-order
	// for(WebNode n: startNode.children) {
	// eularPrintTree(n);
	// }

	// System.out.print(")");

	// if (startNode.isTheLastChild())
	// System.out.print("\n" + repeat("\t", nodeDepth - 2));
	// }

	private String repeat(String str, int repeat) {
		String retVal = "";
		for (int i = 0; i < repeat; i++) {
			retVal += str;
		}
		return retVal;
	}
}
