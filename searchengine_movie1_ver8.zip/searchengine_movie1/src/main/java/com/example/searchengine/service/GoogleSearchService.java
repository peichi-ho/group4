package com.example.searchengine.service;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import org.springframework.stereotype.Service;

@Service
public class GoogleSearchService {
	public GoogleSearchService() {
		Scanner sc = new Scanner(System.in);
		ArrayList keywordArraylist = new ArrayList();
	    KeywordList keywordList = new KeywordList();
	    System.out.println("請輸入查詢關鍵字：");
	    String keyword = sc.nextLine();
	    Keyword userKeyword = new Keyword(keyword, 0, 10); 
	    keywordList.add(userKeyword);
	    keywordArraylist = keywordList.getKeywords();
	    
        try 
        {
        	 GoogleQuery gq = new GoogleQuery(keyword);
             // 呼叫 query 方法，假設 query 需要傳入 KeywordList 中的 keywords
             //HashMap<String, String> results = gq.query(keywordList.getKeywords());
             HashMap<String, String> results = gq.query();  
             System.out.println("Number of results from GoogleQuery: " + results.size());
             
             List<WebNode> roots = new ArrayList<>();
             List<String> urlList = new ArrayList<>(results.values());
             List<String> nameList = new ArrayList<>(results.keySet());
             
             
             for(String url : urlList) {
            	 int index =  urlList.indexOf(url);
            	 String title = nameList.get(index);
            	 
            	 WebPage rootpage = new WebPage(url,title);
                 WebNode root = new WebNode(rootpage);
                 roots.add(root);
                 WebTree tree = new WebTree(root);
                 //下一步要爬子網頁
                 WebPageCrawler crawler = new WebPageCrawler(url);
                 List<String>subPages = crawler.crawl(); 
                 
                 tree.setPostOrderScore(keywordArraylist);
                 
                 //檢查子網頁是否有成功抓取
                 if (subPages.isEmpty()) {
                     System.out.println("No subpages found for URL: " + url);
                 } else {
                     //System.out.println("Total SubPages for URL: " + url + " -> " + subPages.size());
                     //把子網頁和主網頁建成樹
                     for(String suburl:subPages) {
                    	 WebPage subpage = new WebPage(suburl);
                    	 WebNode subnode = new WebNode(subpage);
                    	 root.addChild(subnode);
                    	 
                    	 System.out.println("Adding SubPage: " + suburl);
                       	 String content = gq.getContent(); // 获取子页面内容
                         rootpage.setContent(content); // 更新内容
                         rootpage.setScore(keywordArraylist); // 使用关键字列表计算分数
                      
                       	 subpage.setContent(content); // 更新内容
                         subpage.setScore(keywordArraylist); // 使用关键字列表计算分数
                       	 System.out.println("分數：" + subnode.getScore());
                     }
                 }
                 tree.setPostOrderScore(keywordArraylist);
                 //System.out.println("total score:"+Double.toString(tree.rootscore));
                 //System.out.println("Total Children: " + root.children.size());
                 //tree.eularPrintTree();
                 
             }
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
    
	}
}
