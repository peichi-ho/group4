package com.example.searchengine.service;

import java.util.List;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ArrayList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class WebPage {
    private String url;
    private String name;
    private String content; // 儲存頁面內容
    private double score;   // 儲存分數
    public WordCounter counter;

    //給主網頁
    public WebPage(String url,String name) {
        this.url = url;
        this.name = name;
        this.score = 0.0;
        this.counter = new WordCounter(url);
    }
    //給子網頁
    public WebPage(String url) {
        this.url = url;
        this.score = 0.0;
    }

    public String getUrl() {
        return url;
    }

    public String getName() {
        return name;
    }

    public double getScore() {
        return score;
    }
    
    //這邊要計算到所有子網頁的分數
    public void setScore(ArrayList<Keyword> keywords) throws IOException{
    	try {
			for(Keyword k:keywords) {
				this.score += k.getWeight()*counter.countKeyword(k.getName());
				System.out.println(Double.toString(this.score));
			}
		} catch (IOException e) {
		    e.printStackTrace();
		}
    }
    public void setContent(String content) {
        this.content = content;
        System.out.println("Content set for WebPage: " + name + " | Content preview: " 
                           + content.substring(0, Math.min(100, content.length())) + "...");
    }

    
}
