package com.example.searchengine.service;

import java.io.IOException;
import java.util.ArrayList;



public class WebPage{
	public String url;
	public String name;
	public WordCounter counter;
	public double score;

	public WebPage(String url, String name){
		this.url = url;
		this.name = name;
		this.counter = new WordCounter(url);
	}

	public void setScore(ArrayList<Keyword> keywords) throws IOException {
		score = 0;
		System.out.println("Calculating score for: " + name + " (" + url + ")");
		for (Keyword k : keywords) {
			try {
				int count = counter.countKeyword(k.getName());
				score += count * k.getWeight();
			} catch (IOException e) {
				System.err.println("Error counting keyword: " + k.getName() + " in URL: " + url);
				e.printStackTrace();
			}
		}
		
		System.out.println("Total Score for " + name + ": " + score);
	}
	
}
