package com.example.searchengine.service;

import java.util.ArrayList;

public class KeywordList {
    private ArrayList<Keyword> keywords;

    public KeywordList() {
        this.keywords = new ArrayList<>();
        initializeKeywords();
    }

    private void initializeKeywords() {
        keywords.add(new Keyword("美劇", 4));
        keywords.add(new Keyword("日劇", 4));
        keywords.add(new Keyword("韓劇", 4));
        keywords.add(new Keyword("台劇", 4));
        keywords.add(new Keyword("陸劇", 4));
        keywords.add(new Keyword("音樂劇", 4));
        keywords.add(new Keyword("影評", 2));
        keywords.add(new Keyword("電影", 5));
        keywords.add(new Keyword("演員", 3));
        keywords.add(new Keyword("集數", 3));
        keywords.add(new Keyword("上映日期", 2));
        keywords.add(new Keyword("劇情大綱", 2));
        keywords.add(new Keyword("影視作品", 5));
        keywords.add(new Keyword("IMDb", 5));
        keywords.add(new Keyword("豆瓣", 5));
        keywords.add(new Keyword("Rotten Tomatoes", 5));
    }

    public ArrayList<Keyword> getKeywords() {
        return keywords;
    }
}
