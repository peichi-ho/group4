package com.example.searchengine.service;

import java.io.IOException;
import java.util.Scanner;

public class Main 
{
    public static void main(String[] args) 
    {
    Scanner sc = new Scanner(System.in);
    System.out.println("請輸入查詢關鍵字：");
    String keyword = sc.nextLine();
    sc.close();
        try 
        {
            System.out.println(new GoogleQuery(keyword).query());
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }
}
